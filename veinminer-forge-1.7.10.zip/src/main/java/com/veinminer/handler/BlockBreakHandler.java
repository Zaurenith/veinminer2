package com.veinminer.handler;

import com.veinminer.CommonProxy;
import com.veinminer.KeyBindings;
import com.veinminer.util.BlockWhitelist;
import com.veinminer.util.Coord;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.world.World;
import net.minecraftforge.event.world.BlockEvent;
import org.lwjgl.input.Keyboard;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Client-side vein-mine trigger.
 *
 * BlockEvent.BreakEvent in 1.7.10 is fired from PlayerControllerMP on the
 * client the moment a block finishes breaking (before the server even
 * confirms it), which is exactly what makes a purely client-side
 * implementation possible: we react to that first break, then issue
 * additional break calls through the same PlayerControllerMP the player
 * is already using. Every extra block goes through the normal
 * survival/creative/tool checks and sends the normal packets, so nothing
 * needs to run on the server.
 */
public class BlockBreakHandler {

    // Re-entrancy guard: the extra breaks we trigger below also fire
    // BreakEvent, so we must ignore those or we'd recurse/duplicate work.
    private boolean isChaining = false;

    // (dx, dy, dz, side) for the 6 adjacent directions. Side follows the
    // standard down/up/north/south/west/east ordering used by
    // PlayerControllerMP#onPlayerDestroyBlock.
    private static final int[][] NEIGHBORS = {
            {0, -1, 0, 0},
            {0, 1, 0, 1},
            {0, 0, -1, 2},
            {0, 0, 1, 3},
            {-1, 0, 0, 4},
            {1, 0, 0, 5}
    };

    @SubscribeEvent
    public void onBlockBreak(BlockEvent.BreakEvent event) {
        if (isChaining) {
            return;
        }

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || mc.playerController == null) {
            return;
        }

        // Only trigger for the local player's own break, and only while
        // the vein-mine key is physically held down.
        if (event.getPlayer() != mc.thePlayer) {
            return;
        }
        if (!Keyboard.isKeyDown(KeyBindings.veinMineKey.getKeyCode())) {
            return;
        }

        Block startBlock = event.block;
        int startMeta = event.blockMetadata;

        if (!BlockWhitelist.isWhitelisted(startBlock, startMeta)) {
            return;
        }

        World world = event.world;
        Coord start = new Coord(event.x, event.y, event.z);

        int maxBlocks = CommonProxy.maxBlocksPerActivation;

        Set<Coord> visited = new LinkedHashSet<Coord>();
        visited.add(start);

        Deque<Coord> queue = new ArrayDeque<Coord>();
        queue.add(start);

        int brokenCount = 0;

        isChaining = true;
        try {
            PlayerControllerMP controller = mc.playerController;

            while (!queue.isEmpty() && brokenCount < maxBlocks) {
                Coord current = queue.poll();

                for (int[] dir : NEIGHBORS) {
                    if (brokenCount >= maxBlocks) {
                        break;
                    }

                    Coord next = current.offset(dir[0], dir[1], dir[2]);
                    if (visited.contains(next)) {
                        continue;
                    }
                    visited.add(next);

                    Block block = world.getBlock(next.x, next.y, next.z);
                    int meta = world.getBlockMetadata(next.x, next.y, next.z);

                    // Must match the SAME block+metadata that started the
                    // chain, e.g. gray terracotta only chains into gray
                    // terracotta, quarried stone only into quarried stone.
                    if (block != startBlock || meta != startMeta) {
                        continue;
                    }

                    boolean broke = controller.onPlayerDestroyBlock(next.x, next.y, next.z, dir[3]);
                    if (broke) {
                        brokenCount++;
                        queue.add(next);
                    }
                }
            }
        } finally {
            isChaining = false;
        }
    }
}
